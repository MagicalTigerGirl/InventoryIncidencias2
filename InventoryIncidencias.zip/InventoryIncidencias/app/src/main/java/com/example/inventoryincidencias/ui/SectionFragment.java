package com.example.inventoryincidencias.ui;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.inventoryincidencias.R;
import com.example.inventoryincidencias.adapter.SectionAdapter;
import com.example.inventoryincidencias.data.model.Section;
import com.example.inventoryincidencias.databinding.FragmentSectionBinding;

public class SectionFragment extends Fragment implements SectionAdapter.OnManageSectionManager {

    private FragmentSectionBinding binding;
    private SectionAdapter adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSectionBinding.inflate(inflater);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initRecyclerView();
    }

    private void initRecyclerView() {
        adapter = new SectionAdapter(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());

        binding.rvSection.setLayoutManager(layoutManager);
        binding.rvSection.setAdapter(adapter);
    }

    @Override
    public void onEditSection(Section section) {

    }

    @Override
    public void onDeleteSection(Section section) {

    }
}
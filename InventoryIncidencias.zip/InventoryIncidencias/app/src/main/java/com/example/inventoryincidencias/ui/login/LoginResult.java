package com.example.inventoryincidencias.ui.login;

public enum LoginResult {
    EMAILEMPTY,
    EMAILFORMAT,
    PASSWORDEMPTY,
    PASSWORDFORMAT,
    SUCCESS,
    FAILURE
}
